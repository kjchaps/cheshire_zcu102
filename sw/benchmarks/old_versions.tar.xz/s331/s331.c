#include "s331.h"
#define SCALAR_RES_ADDR ((volatile uint32_t *)0x9FFF0030ULL)

void s331_uint32(const int32_t * restrict a, uint32_t LEN, uint32_t ntimes){

    start_counters();
    int32_t j;
    int32_t chksum;
    for (int nl = 0; nl < ntimes; nl++) {
        j = -1;
        for (int i = 0; i < LEN; i++) {
            if (a[i] < 0) {
                j = i;
            }
        }
        chksum = j;
        dummy(nl);
    }
    stop_counters();

    *SCALAR_RES_ADDR = (int32_t)chksum;
}

void s331_uint8(const int8_t * restrict a,  uint32_t LEN, uint32_t ntimes){

    start_counters();
    
    int32_t j;
    int32_t chksum;
    for (int nl = 0; nl < ntimes; nl++) {
        j = -1;
        for (int i = 0; i < LEN; i++) {
           // if (a[i] < 0) {
                j = a[i];
           // }
        }
        chksum = j;
        dummy(nl);
    }
    
    stop_counters();

    *SCALAR_RES_ADDR = (int32_t)chksum;
}



void s331(uint32_t LEN,  uint32_t EW, uint32_t ntimes){

        if(EW == 32){
                send_setup_info(LEN, 32, __func__);
                s331_uint32(src_int32(), LEN, ntimes);
        }
        else if(EW == 8){
                send_setup_info(LEN, 8, __func__);
                s331_uint8(src_int8(), LEN, ntimes);
        }
        else{
                send_setup_info(LEN, 32, __func__);
                s331_uint32(src_int32(), LEN, ntimes);
        }
        complete_results(__func__);
}




