#ifndef S331_H
#define S331_H

#include <stdint.h>
#include "util.h"
#include "zcu102_util.h"


void s331(uint32_t LEN, uint32_t EW, uint32_t ntimes);

void s331_uint8(const int8_t * restrict a, uint32_t LEN, uint32_t ntimes);

void s331_uint32(const int32_t * restrict a, uint32_t LEN, uint32_t ntimes);

#endif

