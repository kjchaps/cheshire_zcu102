//#include <stdint.h>
//#include "util.h"
//#include "zcu102_util.h"
#include "rvvTest.h"

#define SCALAR_RES_ADDR ((volatile uint32_t *)0x9FFF0030ULL)

void rvvTest_uint32(uint32_t * restrict a, const uint32_t * restrict b, const uint32_t * restrict c, uint32_t LEN) {

    volatile uint32_t *reg_ptr = a;
    uint32_t buffer[LEN];

    start_counters();

    uint64_t r = 0;
    for (uint64_t i = 0; i < LEN; i++) {
        buffer[i] = b[i] + c[i];
    }
    for (uint64_t k = 0; k < LEN; k++) {
        r += buffer[k];
    }

    stop_counters();

    *SCALAR_RES_ADDR = (uint32_t)r;
    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }

}

void rvvTest_uint8(uint8_t * restrict a, const uint8_t * restrict b, const uint8_t * restrict c, uint32_t LEN){

    volatile uint8_t *reg_ptr = a;
    uint8_t buffer[LEN];

    start_counters();

    uint64_t r = 0; 
    for (uint64_t i = 0; i < LEN; i++) {
        buffer[i] = b[i] + c[i];
    }
    for (uint64_t k = 0; k < LEN; k++) {
        r += buffer[k];
    }

    stop_counters();

    *SCALAR_RES_ADDR = (uint32_t)r;
    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }

}



void rvvTest(uint32_t LEN,  uint32_t EW){

	if(EW == 32){
		send_setup_info(LEN, 32, __func__);
                rvvTest_uint32(src_uint32(), src_uint32(), src_uint32(), LEN);
	}
	else if(EW == 8){
		send_setup_info(LEN, 8, __func__);
                rvvTest_uint8(src_uint8(), src_uint8(), src_uint8(), LEN);

	}
	else{
		send_setup_info(LEN, 32, __func__);
		rvvTest_uint32(src_uint32(), src_uint32(), src_uint32(), LEN);
	}
	complete_results(__func__);
}



