#ifndef RVV_TEST_H
#define RVV_TEST_H

#include <stdint.h>
#include "util.h"
#include "zcu102_util.h"



void rvvTest(uint32_t LEN, uint32_t EW);

void rvvTest_uint32(uint32_t * restrict a, const uint32_t * restrict b, const uint32_t * restrict c, uint32_t LEN);

void rvvTest_uint8(uint8_t * restrict a, const uint8_t * restrict b, const uint8_t * restrict c, uint32_t LEN);

#endif
