#include "s131.h"
#define SCALAR_RES_ADDR ((volatile uint32_t *)0x9FFF0030ULL)

void s131_uint32(uint32_t * restrict a, const uint32_t * restrict b,
                 uint32_t LEN, uint32_t ntimes) {

    volatile uint32_t *reg_ptr = a;
    uint32_t buffer[LEN];

    for (uint32_t i = 0; i < LEN; i++) {
        buffer[i] = a[i];
    }

    start_counters();

    int m = 1;
    for (int nl = 0; nl < 5 * ntimes; nl++) {
        for (uint32_t i = 0; i < LEN - 1; i++) {
            buffer[i] = buffer[i + m] + b[i];
        }
        dummy(nl);
    }

    stop_counters();

    *SCALAR_RES_ADDR = (uint32_t)m;
    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }
}
void s131_uint8(uint8_t * restrict a, const uint8_t * restrict b,
                uint32_t LEN, uint32_t ntimes) {

    volatile uint8_t *reg_ptr = a;
    uint8_t buffer[LEN];

    for (uint32_t i = 0; i < LEN; i++) {
        buffer[i] = a[i];
    }

    start_counters();

    int m = 1;
    for (int nl = 0; nl < 5 * ntimes; nl++) {
        for (uint32_t i = 0; i < LEN - 1; i++) {
            buffer[i] = buffer[i + m] + b[i];
        }
        dummy(nl);
    }

    stop_counters();

    *SCALAR_RES_ADDR = (uint32_t)m;
    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }
}


void s131(uint32_t LEN,  uint32_t EW, uint32_t ntimes){

        if(EW == 32){
                send_setup_info(LEN, 32, __func__);
                s131_uint32(src_uint32(), src_uint32(), LEN, ntimes);
        }
        else if(EW == 8){
                send_setup_info(LEN, 8, __func__);
                s131_uint8(src_uint8(), src_uint8(), LEN, ntimes);

        }
        else{
                send_setup_info(LEN, 32, __func__);
                s131_uint32(src_uint32(), src_uint32(), LEN, ntimes);
        }
        complete_results(__func__);
}




