#ifndef S000_H
#define S000_H

#include <stdint.h>
#include "util.h"
#include "zcu102_util.h"


void s000(uint32_t LEN, uint32_t EW, uint32_t ntimes);

void s000_uint8(uint8_t * restrict X, const uint8_t * restrict Y, uint32_t LEN, uint32_t ntimes);

void s000_uint32(uint32_t * restrict X, const uint32_t * restrict Y, uint32_t LEN, uint32_t ntimes);

#endif

