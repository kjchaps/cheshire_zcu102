#include "s000.h"

void s000_uint32(uint32_t * restrict X, const uint32_t * restrict Y, uint32_t LEN, uint32_t ntimes){

    volatile uint32_t *reg_ptr = X;
    uint32_t buffer[LEN];

    start_counters();

    for (int nl = 0; nl < 2*ntimes; nl++) {
            for (int i = 0; i < LEN; i++) {
                buffer[i] = Y[i] + 1;
            }
	dummy(nl);
    }
    
    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }

}

void s000_uint8(uint8_t * restrict X, const uint8_t * restrict Y, uint32_t LEN, uint32_t ntimes){

    volatile uint8_t *reg_ptr = X;
    uint8_t buffer[LEN];

    start_counters();

    for (int nl = 0; nl < 2*ntimes; nl++) {
            for (int i = 0; i < LEN; i++) {
                buffer[i] = Y[i] + 1;
            }
	    dummy(nl);

    }

    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }

}



void s000(uint32_t LEN,  uint32_t EW, uint32_t ntimes){

        if(EW == 32){
                send_setup_info(LEN, 32, __func__);
                s000_uint32(src_uint32(), src_uint32(), LEN, ntimes);
        }
        else if(EW == 8){
                send_setup_info(LEN, 8, __func__);
                s000_uint8(src_uint8(), src_uint8(), LEN, ntimes);

        }
        else{
                send_setup_info(LEN, 32, __func__);
                s000_uint32(src_uint32(), src_uint32(), LEN, ntimes);
        }
        complete_results(__func__);
}




