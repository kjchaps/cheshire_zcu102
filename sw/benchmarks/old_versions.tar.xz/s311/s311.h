#ifndef S311_H
#define S311_H

#include <stdint.h>
#include "util.h"
#include "zcu102_util.h"


void s311(uint32_t LEN, uint32_t EW, uint32_t ntimes);

void s311_uint8(const uint8_t * restrict a, uint32_t LEN, uint32_t ntimes);

void s311_uint32(const uint32_t * restrict a, uint32_t LEN, uint32_t ntimes);

#endif

