#include "s311.h"
#define SCALAR_RES_ADDR ((volatile uint32_t *)0x9FFF0030ULL)

void s311_uint32(const uint32_t * restrict a, uint32_t LEN, uint32_t ntimes){

    start_counters();
    uint32_t sum; 
    for (int nl = 0; nl < ntimes*10; nl++) {
            sum = 0;
	    for (int i = 0; i < LEN; i++) {
                sum += a[i];
            }
	dummy(nl);
    }
    
    stop_counters();

    *SCALAR_RES_ADDR = (uint32_t)sum;
}

void s311_uint8(const uint8_t * restrict a,  uint32_t LEN, uint32_t ntimes){

    start_counters();
    uint32_t sum;
    for (int nl = 0; nl < ntimes*10; nl++) {
            sum = 0;
            for (int i = 0; i < LEN; i++) {
                sum += a[i];
            }
        dummy(nl);
    }

    stop_counters();

    *SCALAR_RES_ADDR = (uint32_t)sum;
}



void s311(uint32_t LEN,  uint32_t EW, uint32_t ntimes){

        if(EW == 32){
                send_setup_info(LEN, 32, __func__);
                s311_uint32(src_uint32(), LEN, ntimes);
        }
        else if(EW == 8){
                send_setup_info(LEN, 8, __func__);
                s311_uint8(src_uint8(), LEN, ntimes);
        }
        else{
                send_setup_info(LEN, 32, __func__);
                s311_uint32(src_uint32(), LEN, ntimes);
        }
        complete_results(__func__);
}




