#ifndef S121_H
#define S121_H

#include <stdint.h>
#include "util.h"
#include "zcu102_util.h"

void s121(uint32_t LEN, uint32_t EW, uint32_t ntimes);

void s121_uint8(uint8_t * restrict a, const uint8_t * restrict b, uint32_t LEN, uint32_t ntimes);

void s121_uint32(uint32_t * restrict a, const uint32_t * restrict b, uint32_t LEN, uint32_t ntimes);

#endif
