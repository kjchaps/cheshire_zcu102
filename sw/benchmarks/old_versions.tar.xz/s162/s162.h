#ifndef S162_H
#define S162_H

#include <stdint.h>
#include "util.h"
#include "zcu102_util.h"


void s162(uint32_t LEN, uint32_t EW, uint32_t ntimes, int k);

void s162_uint8(uint8_t * restrict a, const uint8_t * restrict b, const uint8_t * restrict c, uint32_t LEN, uint32_t ntimes, int k);

void s162_uint32(uint32_t * restrict a, const uint32_t * restrict b, const uint32_t * restrict c, uint32_t LEN, uint32_t ntimes, int k);

#endif

