#include "s162.h"


void s162_uint32(uint32_t * restrict a, const uint32_t * restrict b, const uint32_t * restrict c, uint32_t LEN, uint32_t ntimes, int k) {

    volatile uint32_t *reg_ptr = a;
    uint32_t buffer[LEN];

    for (uint32_t i = 0; i < LEN; i++) {
        buffer[i] = a[i];
    }

    start_counters();

    for (int nl = 0; nl < ntimes; nl++) {
        if (k > 0) {
            for (uint32_t i = 0; i < LEN - 1; i++) {
                buffer[i] = buffer[i + k] + b[i] * c[i];
            }
            dummy(nl);
        }
    }

    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }
}


void s162_uint8(uint8_t * restrict a, const uint8_t * restrict b, const uint8_t * restrict c, uint32_t LEN, uint32_t ntimes, int k){

    volatile uint8_t *reg_ptr = a;
    uint8_t buffer[LEN];

    for (uint32_t i = 0; i < LEN; i++) {
        buffer[i] = a[i];
    }

    start_counters();

    for (int nl = 0; nl < ntimes; nl++) {
        if (k > 0) {
            for (int i = 0; i < LEN - 1; i++) {
                buffer[i] = buffer[i + k] + b[i] * c[i];
            }
            dummy(nl);
        }
    }

    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }
}

void s162(uint32_t LEN,  uint32_t EW, uint32_t ntimes, int k){

        if(EW == 32){
                send_setup_info(LEN, 32, __func__);
                s162_uint32(src_uint32(), src_uint32(), src_uint32(), LEN, ntimes, k);
        }
        else if(EW == 8){
                send_setup_info(LEN, 8, __func__);
                s162_uint8(src_uint8(), src_uint8(), src_uint8(), LEN, ntimes, k);

        }
        else{
                send_setup_info(LEN, 32, __func__);
                s162_uint32(src_uint32(), src_uint32(), src_uint32(), LEN, ntimes, k);
        }
        complete_results(__func__);
}




