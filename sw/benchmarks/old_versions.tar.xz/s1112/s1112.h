#ifndef S1112_H
#define S1112_H

#include <stdint.h>
#include "util.h"
#include "zcu102_util.h"


void s1112(uint32_t LEN, uint32_t EW, uint32_t ntimes);

void s1112_uint8(uint8_t * restrict a, const uint8_t * restrict b, uint32_t LEN, uint32_t ntimes);

void s1112_uint32(uint32_t * restrict a, const uint32_t * restrict b, uint32_t LEN, uint32_t ntimes);

#endif

