#include "s1112.h"

void s1112_uint32(uint32_t * restrict a, const uint32_t * restrict b,
                 uint32_t LEN, uint32_t ntimes) {

    volatile uint32_t *reg_ptr = a;
    uint32_t buffer[LEN];

    for (uint32_t i = 0; i < LEN; i++) {
        buffer[i] = a[i];
    }

    start_counters();

    for (int nl = 0; nl < 3 * ntimes; nl++) {
        for (int i = (int)LEN - 1; i >= 0; i--) {
            buffer[i + 1] = buffer[i] + b[i];
        }
        dummy(nl);
    }

    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }
}

void s1112_uint8(uint8_t * restrict a, const uint8_t * restrict b,
                uint32_t LEN, uint32_t ntimes) {

    volatile uint8_t *reg_ptr = a;
    uint8_t buffer[LEN];

    for (uint32_t i = 0; i < LEN; i++) {
        buffer[i] = a[i];
    }

    start_counters();

    for (int nl = 0; nl < 2*ntimes; nl++) {
            for (int i = 0; i < LEN; i++) {
                buffer[i] = b[i] + 1;
            }
	    dummy(nl);

    }
    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }
}


void s1112(uint32_t LEN,  uint32_t EW, uint32_t ntimes){

        if(EW == 32){
                send_setup_info(LEN, 32, __func__);
                s1112_uint32(src_uint32(), src_uint32(), LEN, ntimes);
        }
        else if(EW == 8){
                send_setup_info(LEN, 8, __func__);
                s1112_uint8(src_uint8(), src_uint8(), LEN, ntimes);

        }
        else{
                send_setup_info(LEN, 32, __func__);
                s1112_uint32(src_uint32(), src_uint32(), LEN, ntimes);
        }
        complete_results(__func__);
}




