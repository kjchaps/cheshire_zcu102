#include "s251.h"

void s251_uint32(uint32_t * restrict a, const uint32_t * restrict b, const uint32_t * restrict c, const uint32_t * restrict d, uint32_t LEN, uint32_t ntimes){

    volatile uint32_t *reg_ptr = a;
    uint32_t buffer[LEN];

    start_counters();
    uint32_t s; 
    
    for (int nl = 0; nl < 4*ntimes; nl++) {
        for (int i = 0; i < LEN; i++) {
            s = b[i] + c[i] * d[i];
            buffer[i] = s * s;
        }
        dummy(nl);
    }
    
    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }

}

void s251_uint8(uint8_t * restrict a, const uint8_t * restrict b, const uint8_t * restrict c, const uint8_t * restrict d, uint32_t LEN, uint32_t ntimes){

    volatile uint8_t *reg_ptr = a;
    uint8_t buffer[LEN];

    start_counters();

    uint32_t s;

    for (int nl = 0; nl < 4*ntimes; nl++) {
        for (int i = 0; i < LEN; i++) {
            s = b[i] + c[i] * d[i];
            buffer[i] = s * s;
        }
        dummy(nl);
    }


    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }

}



void s251(uint32_t LEN,  uint32_t EW, uint32_t ntimes){

        if(EW == 32){
                send_setup_info(LEN, 32, __func__);
                s251_uint32(src_uint32(), src_uint32(), src_uint32(), src_uint32(), LEN, ntimes);
        }
        else if(EW == 8){
                send_setup_info(LEN, 8, __func__);
                s251_uint8(src_uint8(), src_uint8(), src_uint8(), src_uint8(), LEN, ntimes);

        }
        else{
                send_setup_info(LEN, 32, __func__);
                s251_uint32(src_uint32(), src_uint32(), src_uint32(), src_uint32(), LEN, ntimes);
        }
        complete_results(__func__);
}




