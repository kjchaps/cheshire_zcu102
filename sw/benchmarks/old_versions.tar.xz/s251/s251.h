#ifndef S251_H
#define S251_H

#include <stdint.h>
#include "util.h"
#include "zcu102_util.h"


void s251(uint32_t LEN, uint32_t EW, uint32_t ntimes);

void s251_uint8(uint8_t * restrict a, const uint8_t * restrict b, const uint8_t * restrict c, const uint8_t * restrict d, uint32_t LEN, uint32_t ntimes);

void s251_uint32(uint32_t * restrict a, const uint32_t * restrict b, const uint32_t * restrict c, const uint32_t * restrict d, uint32_t LEN, uint32_t ntimes);

#endif

