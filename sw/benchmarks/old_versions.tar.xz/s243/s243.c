#include "s243.h"

void s243_uint32(uint32_t * restrict a, uint32_t * restrict b,
                 const uint32_t * restrict c, const uint32_t * restrict d,
                 const uint32_t * restrict e, uint32_t LEN, uint32_t ntimes) {

    volatile uint32_t *reg_ptr_a = a;
    volatile uint32_t *reg_ptr_b = b;
    uint32_t buffer_a[LEN];
    uint32_t buffer_b[LEN];

    for (uint32_t i = 0; i < LEN; i++) {
        buffer_a[i] = a[i];
        buffer_b[i] = b[i];
    }

    start_counters();

    for (int nl = 0; nl < ntimes; nl++) {
        for (uint32_t i = 0; i < LEN - 1; i++) {
            buffer_a[i] = buffer_b[i] + c[i] * d[i];
            buffer_b[i] = buffer_a[i] + d[i] * e[i];
            buffer_a[i] = buffer_b[i] + buffer_a[i + 1] * d[i];
        }
        dummy(nl);
    }

    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr_a[i] = buffer_a[i];
        reg_ptr_b[i] = buffer_b[i];
    }
}

void s243_uint8(uint8_t * restrict a, uint8_t * restrict b, const uint8_t * restrict c, const uint8_t * restrict d, const uint8_t * restrict e, uint32_t LEN, uint32_t ntimes){

    volatile uint8_t *reg_ptr_a = a;
    volatile uint8_t *reg_ptr_b = b;
    uint8_t buffer_a[LEN];
    uint8_t buffer_b[LEN];

    for (uint32_t i = 0; i < LEN; i++) {
        buffer_a[i] = a[i];
        buffer_b[i] = b[i];
    }

    start_counters();

    for (int nl = 0; nl < ntimes; nl++) {
        for (uint32_t i = 0; i < LEN - 1; i++) {
            buffer_a[i] = buffer_b[i] + c[i] * d[i];
            buffer_b[i] = buffer_a[i] + d[i] * e[i];
            buffer_a[i] = buffer_b[i] + buffer_a[i + 1] * d[i];
        }
        dummy(nl);
    }

    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr_a[i] = buffer_a[i];
        reg_ptr_b[i] = buffer_b[i];
    }

}

void s243(uint32_t LEN,  uint32_t EW, uint32_t ntimes){

        if(EW == 32){
                send_setup_info(LEN, 32, __func__);
                s243_uint32(src_uint32(), src_uint32(), src_uint32(), src_uint32(), src_uint32(), LEN, ntimes);
        }
        else if(EW == 8){
                send_setup_info(LEN, 8, __func__);
                s243_uint8(src_uint8(), src_uint8(), src_uint8(), src_uint8(), src_uint8(), LEN, ntimes);
        }
        else{
                send_setup_info(LEN, 32, __func__);
                s243_uint32(src_uint32(), src_uint32(), src_uint32(), src_uint32(), src_uint32(), LEN, ntimes);
        }
        complete_results(__func__);
}





