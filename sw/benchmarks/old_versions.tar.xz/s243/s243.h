#ifndef S243_H
#define S243_H

#include <stdint.h>
#include "util.h"
#include "zcu102_util.h"


void s243(uint32_t LEN, uint32_t EW, uint32_t ntimes);

void s243_uint8(uint8_t * restrict a, uint8_t * restrict b, const uint8_t * restrict c, const uint8_t * restrict d, const uint8_t * restrict e, uint32_t LEN, uint32_t ntimes);

void s243_uint32(uint32_t * restrict a, uint32_t * restrict b, const uint32_t * restrict c, const uint32_t * restrict d, const uint32_t * restrict e, uint32_t LEN, uint32_t ntimes);

#endif

