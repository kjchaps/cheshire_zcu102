#include "s171.h"

void s171_uint32(uint32_t * restrict a, const uint32_t * restrict b, uint32_t LEN, uint32_t ntimes, int inc){

    volatile uint32_t *reg_ptr = a;
    uint32_t buffer[LEN];

    start_counters();

   for (int nl = 0; nl < ntimes; nl++) {
        for (int i = 0; i < LEN; i++) {
            buffer[i * inc] += b[i];
        }
	dummy(nl);
    }


    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }

}

void s171_uint8(uint8_t * restrict a, const uint8_t * restrict b, uint32_t LEN, uint32_t ntimes, int inc){

    volatile uint8_t *reg_ptr = a;
    uint8_t buffer[LEN];

    start_counters();

    for (int nl = 0; nl < ntimes; nl++) {
        for (int i = 0; i < LEN; i++) {
            buffer[i * inc] += b[i];
        }
	dummy(nl);
    }

    stop_counters();

    for (uint32_t i = 0; i < LEN; i++) {
        reg_ptr[i] = buffer[i];
    }

}



void s171(uint32_t LEN,  uint32_t EW, uint32_t ntimes, int inc){

        if(EW == 32){
                send_setup_info(LEN, 32, __func__);
                s171_uint32(src_uint32(), src_uint32(), LEN, ntimes, inc);
        }
        else if(EW == 8){
                send_setup_info(LEN, 8, __func__);
                s171_uint8(src_uint8(), src_uint8(), LEN, ntimes, inc);
        }
        else{
                send_setup_info(LEN, 32, __func__);
                s171_uint32(src_uint32(), src_uint32(), LEN, ntimes, inc);
        }
        complete_results(__func__);
}




