#ifndef S171_H
#define S171_H

#include <stdint.h>
#include "util.h"
#include "zcu102_util.h"


void s171(uint32_t LEN, uint32_t EW, uint32_t ntimes, int inc);

void s171_uint8(uint8_t * restrict a, const uint8_t * restrict b, uint32_t LEN, uint32_t ntimes, int inc);

void s171_uint32(uint32_t * restrict a, const uint32_t * restrict b, uint32_t LEN, uint32_t ntimes, int inc);

#endif

